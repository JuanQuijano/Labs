import React, { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { TaskForm } from './components/TaskForm';
import { TaskList } from './components/TaskList';
import { Button } from './components/ui/Button';
import { useTaskStore } from './store/useTaskStore';
import { Task } from './types/task';

function App() {
  const { tasks, isLoading, error, fetchTasks, createTask, updateTask, deleteTask } = useTaskStore();
  const [isCreating, setIsCreating] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleCreateSubmit = async (data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => {
    await createTask(data);
    setIsCreating(false);
  };

  const handleUpdateSubmit = async (data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingTask) {
      await updateTask(editingTask.id, data);
      setEditingTask(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      await deleteTask(id);
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            <p>Error: {error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Task Manager</h1>
            <Button
              onClick={() => setIsCreating(true)}
              className="flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>New Task</span>
            </Button>
          </div>

          {isCreating && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Create New Task</h2>
              <TaskForm
                onSubmit={handleCreateSubmit}
                onCancel={() => setIsCreating(false)}
              />
            </div>
          )}

          {editingTask && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Edit Task</h2>
              <TaskForm
                initialData={editingTask}
                onSubmit={handleUpdateSubmit}
                onCancel={() => setEditingTask(null)}
              />
            </div>
          )}

          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
            </div>
          ) : (
            <TaskList
              tasks={tasks}
              onEdit={setEditingTask}
              onDelete={handleDelete}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;