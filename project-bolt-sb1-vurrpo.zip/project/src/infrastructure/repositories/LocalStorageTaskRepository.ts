import { v4 as uuidv4 } from 'uuid';
import { Task } from '../../types/task';
import { TaskRepository } from '../../domain/repositories/TaskRepository';

export class LocalStorageTaskRepository implements TaskRepository {
  private readonly storageKey = 'tasks';

  private async getTasks(): Promise<Task[]> {
    const tasks = localStorage.getItem(this.storageKey);
    return tasks ? JSON.parse(tasks) : [];
  }

  private async saveTasks(tasks: Task[]): Promise<void> {
    localStorage.setItem(this.storageKey, JSON.stringify(tasks));
  }

  async getAll(): Promise<Task[]> {
    return this.getTasks();
  }

  async getById(id: string): Promise<Task | null> {
    const tasks = await this.getTasks();
    return tasks.find(task => task.id === id) || null;
  }

  async create(taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Promise<Task> {
    const tasks = await this.getTasks();
    const newTask: Task = {
      ...taskData,
      id: uuidv4(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    await this.saveTasks([...tasks, newTask]);
    return newTask;
  }

  async update(id: string, taskData: Partial<Task>): Promise<Task> {
    const tasks = await this.getTasks();
    const taskIndex = tasks.findIndex(task => task.id === id);
    
    if (taskIndex === -1) {
      throw new Error('Task not found');
    }

    const updatedTask: Task = {
      ...tasks[taskIndex],
      ...taskData,
      updatedAt: new Date()
    };

    tasks[taskIndex] = updatedTask;
    await this.saveTasks(tasks);
    
    return updatedTask;
  }

  async delete(id: string): Promise<void> {
    const tasks = await this.getTasks();
    const filteredTasks = tasks.filter(task => task.id !== id);
    await this.saveTasks(filteredTasks);
  }
}